const _ = require('underscore');
console.log(_.range(5));